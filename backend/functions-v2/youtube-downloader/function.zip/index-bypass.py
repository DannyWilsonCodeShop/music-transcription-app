"""
Lambda: YouTube Downloader with enhanced bot bypass
Downloads audio from YouTube using yt-dlp with multiple bypass techniques
"""

import json
import boto3
import os
import logging
import yt_dlp
from datetime import datetime
from urllib.parse import urlparse, parse_qs

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

AUDIO_BUCKET = os.environ['S3_AUDIO_BUCKET']
JOBS_TABLE = os.environ['DYNAMODB_JOBS_TABLE']

def lambda_handler(event, context):
    """Download YouTube audio using yt-dlp with enhanced bypass"""
    
    logger.info(f"Event: {json.dumps(event)}")
    
    try:
        job_id = event['jobId']
        youtube_url = event['youtubeUrl']
        video_id = event.get('videoId', extract_video_id(youtube_url))
        
        # Update job status
        update_job_status(job_id, 'DOWNLOADING', 10)
        
        logger.info(f"Downloading audio from {youtube_url} using yt-dlp with bypass")
        
        # Download audio using yt-dlp with enhanced options
        audio_path, metadata = download_with_ytdlp(youtube_url, job_id)
        
        file_size = os.path.getsize(audio_path)
        logger.info(f"Downloaded {file_size} bytes")
        
        # Upload to S3
        s3_key = f'audio/{job_id}.mp3'
        
        logger.info(f"Uploading to S3: {AUDIO_BUCKET}/{s3_key}")
        
        with open(audio_path, 'rb') as f:
            s3_client.put_object(
                Bucket=AUDIO_BUCKET,
                Key=s3_key,
                Body=f,
                ContentType='audio/mpeg'
            )
        
        logger.info("Upload complete")
        
        # Update job with download info
        update_job_status(job_id, 'DOWNLOADED', 20)
        
        return {
            'statusCode': 200,
            'body': {
                'jobId': job_id,
                's3Key': s3_key,
                'videoTitle': metadata.get('title', 'Unknown'),
                'duration': metadata.get('duration', 0)
            }
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        update_job_status(job_id, 'FAILED', 0, str(e))
        return {
            'statusCode': 500,
            'body': {'error': str(e)}
        }

def download_with_ytdlp(youtube_url, job_id):
    """Download audio using yt-dlp with enhanced bot bypass techniques"""
    
    # Copy cookies from layer to /tmp if available
    import shutil
    cookies_path = '/tmp/cookies.txt'
    if os.path.exists('/opt/cookies.txt'):
        shutil.copy('/opt/cookies.txt', cookies_path)
        logger.info("Copied cookies to /tmp")
    
    output_path = f'/tmp/{job_id}.mp3'
    
    # Enhanced yt-dlp options to bypass bot detection
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': output_path.replace('.mp3', ''),
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'quiet': False,
        'no_warnings': False,
        
        # Bot bypass options
        'extractor_args': {
            'youtube': {
                'player_client': ['android', 'web'],
                'player_skip': ['webpage', 'configs'],
            }
        },
        
        # Use cookies if available
        'cookiefile': cookies_path if os.path.exists(cookies_path) else None,
        
        # Additional headers to appear more like a real browser
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-us,en;q=0.5',
            'Sec-Fetch-Mode': 'navigate',
        },
        
        # Retry options
        'retries': 3,
        'fragment_retries': 3,
        
        # Use IPv4 only (sometimes helps)
        'source_address': '0.0.0.0',
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            logger.info(f"Extracting info for {youtube_url}")
            info = ydl.extract_info(youtube_url, download=True)
            
            metadata = {
                'title': info.get('title', 'Unknown'),
                'duration': info.get('duration', 0),
                'uploader': info.get('uploader', 'Unknown'),
            }
            
            logger.info(f"Downloaded: {metadata['title']}")
            
            return output_path, metadata
            
    except Exception as e:
        logger.error(f"yt-dlp error: {str(e)}")
        raise Exception(f"Failed to download audio: {str(e)}")

def extract_video_id(youtube_url):
    """Extract video ID from YouTube URL"""
    parsed = urlparse(youtube_url)
    if parsed.hostname in ['www.youtube.com', 'youtube.com']:
        query = parse_qs(parsed.query)
        return query.get('v', [None])[0]
    elif parsed.hostname == 'youtu.be':
        return parsed.path[1:]
    return None

def update_job_status(job_id, status, progress, error=None):
    """Update job status in DynamoDB"""
    try:
        table = dynamodb.Table(JOBS_TABLE)
        update_expr = 'SET #status = :status, progress = :progress, updatedAt = :updated'
        expr_values = {
            ':status': status,
            ':progress': progress,
            ':updated': datetime.utcnow().isoformat() + 'Z'
        }
        
        if error:
            update_expr += ', errorMessage = :error'
            expr_values[':error'] = str(error)[:500]
        
        table.update_item(
            Key={'jobId': job_id},
            UpdateExpression=update_expr,
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues=expr_values
        )
    except Exception as e:
        logger.error(f"Failed to update job status: {str(e)}")
